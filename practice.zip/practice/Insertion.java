public class Insertion {
    void insertionSorting(int arr[]){
        int n = arr.length;
        for(int i = 1; i < n ; i++){
            int temp = arr[i];
            int j = i-1;
            while(j>-1 && arr[j]>temp){
                arr[j+1] = arr[j];
                j--;
            }
            arr[j+1]=temp;
        }
    }

    void printArray(int arr[]){
        System.out.println("Sorted Array : ");
        for(int i : arr){
            System.out.print(i+" ");
            }
    }

    public static void main(String[] args){
        Insertion sort = new Insertion();
        int arr[] = {20,50,10,70,60};
        sort.insertionSorting(arr);
        sort.printArray(arr);
        
    }
}
