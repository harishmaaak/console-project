class BubbleSort{
    public void bubbleSort(int[] arr){
        int n = arr.length;
        int temp = 0;
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n-1; j++){
               if(arr[j+1] < arr[j]){
                   temp = arr[j];
                   arr[j] = arr[j+1];
                   arr[j+1] = temp;                   
               }
            }
        }
    }
    
    void printArray(int[] arr){
        int n = arr.length;
        for(int i = 0; i < n; i++){
            System.out.print(arr[i]+" ");
        }
    }

    public static void main(String[] args){
        BubbleSort sort = new BubbleSort();
        int arr[] = {22,45,12,56,34};
        sort.bubbleSort(arr);
        System.out.println("Sorting : ");
        sort.printArray(arr);
    }
}